const { spawnSync } = require('child_process');
const path = require('path');

const script = path.join(__dirname, '..', 'ai', 'matcher.py');
const candidates = process.platform === 'win32'
  ? [['python', [script, '--selftest']], ['py', ['-3', script, '--selftest']]]
  : [['python3', [script, '--selftest']], ['python', [script, '--selftest']]];

for (const [command, args] of candidates) {
  const result = spawnSync(command, args, { stdio: 'inherit', shell: false });
  if (!result.error) process.exit(result.status || 0);
}

console.error('Python is required for the optional AI matching self-test.');
process.exit(1);
