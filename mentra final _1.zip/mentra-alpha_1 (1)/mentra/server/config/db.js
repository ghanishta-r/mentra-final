const mongoose = require("mongoose");
let memoryServer;

module.exports = async function connectDB() {
  const configuredUri = process.env.MONGO_URI;
  const localUri = configuredUri || 'mongodb://127.0.0.1:27017/mentra';

  try {
    await mongoose.connect(localUri, { serverSelectionTimeoutMS: configuredUri ? 10000 : 2000 });
    console.log(`MongoDB connected: ${mongoose.connection.host}/${mongoose.connection.name}`);
  } catch (error) {
    if (process.env.NODE_ENV === 'production' || configuredUri) throw error;
    try {
      const { MongoMemoryServer } = require('mongodb-memory-server');
      memoryServer = await MongoMemoryServer.create({ instance: { dbName: 'mentra' } });
      await mongoose.connect(memoryServer.getUri());
      console.warn('Local MongoDB was unavailable. Using an ephemeral in-memory database.');
      console.log(`MongoDB connected: ${mongoose.connection.host}/${mongoose.connection.name}`);
    } catch (memoryError) {
      throw new Error(`MongoDB unavailable at ${localUri}. ${memoryError.message}`);
    }
  }
};
