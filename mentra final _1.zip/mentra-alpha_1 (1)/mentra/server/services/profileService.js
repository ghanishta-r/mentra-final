const MentorProfile = require('../models/MentorProfile');
const MenteeProfile = require('../models/MenteeProfile');

exports.profileFor = async (user) => {
  const Model = user.role === 'mentor' ? MentorProfile : MenteeProfile;
  const existing = await Model.findOne({ user: user._id });
  if (existing) return existing;
  return Model.create({ user: user._id });
};

exports.isComplete = (role, p) => {
  if (!p) return false;
  if (role === 'mentor') return !!(p.headline && p.bio && p.skills && p.skills.length);
  return !!(p.learningGoals && ((p.interests && p.interests.length) || (p.skills && p.skills.length)));
};
