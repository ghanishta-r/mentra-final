require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const app = require('./app');
const connectDB = require('./config/db');

if (!process.env.JWT_SECRET) {
  if (process.env.NODE_ENV === 'production') {
    console.error('JWT_SECRET is required in production. Copy .env.example to .env and set it.');
    process.exit(1);
  }
  process.env.JWT_SECRET = require('crypto').randomBytes(48).toString('hex');
  console.warn('JWT_SECRET is missing. Using a temporary development secret.');
}

const port = process.env.PORT || 5000;

connectDB()
  .then(() => app.listen(port, () => console.log(`MENTRA running on http://localhost:${port}`)))
  .catch((err) => { console.error('Startup failed:', err.message); process.exit(1); });
