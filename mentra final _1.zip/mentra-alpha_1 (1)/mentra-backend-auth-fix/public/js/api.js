// Auto-resolves backend URL whether opened via http://localhost:5000 or Live Server (:5500)
const API_BASE =
  window.location.port && window.location.port !== '5000'
    ? 'http://localhost:5000/api'
    : '/api';

async function apiRequest(endpoint, options = {}) {
  const url = endpoint.startsWith('http') ? endpoint : `${API_BASE}${endpoint}`;
  const config = {
    credentials: 'include', // Required so mentra_token cookie is sent and stored
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  };

  if (config.body && typeof config.body !== 'string') {
    config.body = JSON.stringify(config.body);
  }

  const response = await fetch(url, config);
  let data = {};
  try {
    data = await response.json();
  } catch (_e) {
    data = { success: false, message: `Server returned status ${response.status}` };
  }

  if (!response.ok || data.success === false) {
    throw new Error(data.message || `Request failed (${response.status})`);
  }

  return data;
}

window.mentraApi = { apiRequest, API_BASE };
