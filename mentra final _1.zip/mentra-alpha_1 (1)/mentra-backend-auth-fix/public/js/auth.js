// Drop-in frontend auth handlers using credentials: 'include'
async function handleLogin(email, password) {
  return window.mentraApi.apiRequest('/auth/login', {
    method: 'POST',
    body: { email, password },
  });
}

async function handleRegister(payload) {
  return window.mentraApi.apiRequest('/auth/register', {
    method: 'POST',
    body: payload,
  });
}

async function handleLogout() {
  return window.mentraApi.apiRequest('/auth/logout', {
    method: 'POST',
  });
}

async function getCurrentUser() {
  return window.mentraApi.apiRequest('/auth/me', {
    method: 'GET',
  });
}

window.mentraAuth = { handleLogin, handleRegister, handleLogout, getCurrentUser };
