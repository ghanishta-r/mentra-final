const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { COOKIE_NAME } = require('../middleware/auth');

function buildCookieOptions() {
  const isProd = process.env.NODE_ENV === 'production';
  const crossOrigin = Boolean(process.env.CLIENT_ORIGIN);
  return {
    httpOnly: true,
    secure: isProd,
    // Use 'lax' in local dev or 'none' (with secure) if cross-origin frontend is configured
    sameSite: crossOrigin && isProd ? 'none' : 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/',
  };
}

function signToken(userId) {
  const secret = process.env.JWT_SECRET;
  if (!secret || secret === 'change-this-to-a-long-random-string') {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('JWT_SECRET must be configured in production.');
    }
  }
  return jwt.sign({ id: userId }, secret || 'dev-fallback-secret-change-me', {
    expiresIn: '7d',
  });
}

function sanitizeUser(user) {
  return {
    id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    department: user.department,
    year: user.year,
    bio: user.bio,
    headline: user.headline,
    skills: user.skills,
    interests: user.interests,
    goals: user.goals,
    available: user.available,
  };
}

exports.register = async (req, res, next) => {
  try {
    const { name, email, password, role, department, year } = req.body;
    const normalizedEmail = email.trim().toLowerCase();

    const existing = await User.findOne({ email: normalizedEmail });
    if (existing) {
      return res.status(409).json({ success: false, message: 'Email is already registered.' });
    }

    const user = await User.create({
      name: name.trim(),
      email: normalizedEmail,
      password,
      role: role || 'mentee',
      department: department || '',
      year: year || '',
    });

    const token = signToken(user._id);
    res.cookie(COOKIE_NAME, token, buildCookieOptions());

    return res.status(201).json({
      success: true,
      user: sanitizeUser(user),
    });
  } catch (err) {
    next(err);
  }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const normalizedEmail = email.trim().toLowerCase();

    const user = await User.findOne({ email: normalizedEmail }).select('+password');
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const token = signToken(user._id);
    res.cookie(COOKIE_NAME, token, buildCookieOptions());

    return res.status(200).json({
      success: true,
      user: sanitizeUser(user),
    });
  } catch (err) {
    next(err);
  }
};

exports.logout = (_req, res) => {
  const opts = buildCookieOptions();
  res.clearCookie(COOKIE_NAME, {
    httpOnly: opts.httpOnly,
    secure: opts.secure,
    sameSite: opts.sameSite,
    path: '/',
  });
  return res.status(200).json({ success: true, message: 'Logged out successfully.' });
};

exports.me = async (req, res) => {
  return res.status(200).json({
    success: true,
    user: sanitizeUser(req.user),
  });
};
