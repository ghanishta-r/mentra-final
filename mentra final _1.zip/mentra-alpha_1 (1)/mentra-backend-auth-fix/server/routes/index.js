const express = require('express');
const authRoutes = require('./authRoutes');
const { protect } = require('../middleware/auth');
const User = require('../models/User');

const router = express.Router();

router.get('/health', (_req, res) => {
  res.status(200).json({ success: true, status: 'ok', timestamp: new Date().toISOString() });
});

router.get('/public/stats', async (_req, res, next) => {
  try {
    const [mentors, mentees] = await Promise.all([
      User.countDocuments({ role: 'mentor' }),
      User.countDocuments({ role: 'mentee' }),
    ]);
    res.json({ success: true, mentors, mentees });
  } catch (err) {
    next(err);
  }
});

router.use('/auth', authRoutes);

// Protected profile routes
router.get('/profiles/me', protect, (req, res) => {
  res.json({ success: true, profile: req.user });
});

router.put('/profiles/me', protect, async (req, res, next) => {
  try {
    const allowed = ['name', 'department', 'year', 'bio', 'headline', 'skills', 'interests', 'goals', 'available'];
    for (const key of allowed) {
      if (req.body[key] !== undefined) {
        req.user[key] = req.body[key];
      }
    }
    await req.user.save();
    res.json({ success: true, profile: req.user });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
